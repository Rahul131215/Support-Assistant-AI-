import React, { useState, useEffect, useCallback } from 'react';
import Layout from './components/Layout';
import ChatInterface from './components/ChatInterface';
import TicketPanel from './components/TicketPanel';
import KnowledgeBase from './components/KnowledgeBase';
import SettingsPanel from './components/SettingsPanel';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import { Message, Ticket, EscalationParams, ActiveTab } from './types';
import { initializeChat, sendMessageToGemini } from './services/geminiService';
import { db } from './services/databaseService';

// Helper to safely get env var
const getApiKey = () => {
  try {
    return process.env.API_KEY || "";
  } catch (e) {
    return "";
  }
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  
  // App State
  const [messages, setMessages] = useState<Message[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [knowledgeBase, setKnowledgeBase] = useState<any[]>([]);
  
  // Chat State
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(false);

  // Initialize Data
  useEffect(() => {
    const initData = async () => {
      try {
        const savedTickets = await db.getTickets();
        const savedMessages = await db.getMessages();
        const kb = await db.getKnowledgeBase();
        
        setTickets(savedTickets || []);
        setKnowledgeBase(kb || []);

        const apiKey = getApiKey();

        if (savedMessages && savedMessages.length > 0) {
            setMessages(savedMessages);
        } else if (apiKey) {
            // Initial greeting if no history
             setMessages([{
                id: 'init-1',
                role: 'model',
                content: "Hello! I'm your Support Assistant. I can help with billing, account issues, or tech support. How can I help you today?",
                timestamp: new Date().toISOString()
            }]);
        }
      } catch (err) {
        console.error("Failed to initialize app data", err);
      }
    };
    initData();

    const apiKey = getApiKey();
    if (apiKey) {
      initializeChat(apiKey);
      setHasApiKey(true);
    }
  }, []);

  const refreshTickets = async () => {
      const t = await db.getTickets();
      setTickets(t || []);
  };

  // Tool Handler (Client Side Execution)
  const handleToolCall = async (name: string, args: any): Promise<string> => {
    
    // Simulate network delay to make it feel like a real backend
    await new Promise(resolve => setTimeout(resolve, 1500));

    if (name === 'escalate_ticket') {
      const { summary, priority, reason } = args as EscalationParams;
      
      const newTicket: Ticket = {
        id: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
        title: summary,
        description: `${reason} (Auto-escalated by AI)`,
        priority: priority as any,
        status: 'Open',
        source: 'Chat Escalation',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      await db.createTicket(newTicket);
      await refreshTickets();
      
      return `Ticket created successfully with ID ${newTicket.id}. A human agent will review it shortly.`;
    }
    
    if (name === 'check_order_status') {
      // Mock order check
      const statuses = ['Processing', 'Shipped', 'Delivered', 'Cancelled', 'On Hold'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      return `Order ${args.orderId} is currently: ${randomStatus}. Updated 2 minutes ago.`;
    }

    return "Tool execution failed: Unknown tool.";
  };

  const handleSendMessage = useCallback(async () => {
    if (!input.trim() || !hasApiKey || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    await db.saveMessage(userMsg); // Persist user message

    setInput('');
    setIsLoading(true);

    try {
      const responseText = await sendMessageToGemini(input, handleToolCall);
      
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: responseText,
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, aiMsg]);
      await db.saveMessage(aiMsg); // Persist AI message

    } catch (error) {
      console.error("Failed to send message", error);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: "I'm having trouble connecting to the server right now. Please try again later.",
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  }, [input, hasApiKey, isLoading]);

  // Settings Actions
  const handleClearHistory = async () => {
    await db.clearMessages();
    setMessages([{
      id: Date.now().toString(),
      role: 'model',
      content: "Chat history cleared. How can I help you?",
      timestamp: new Date().toISOString()
    }]);
    initializeChat(getApiKey());
  };

  const handleResetSystem = async () => {
    await db.resetSystem();
    setTickets([]);
    setMessages([]); // Will be re-inited by clearHistory effectively
    handleClearHistory();
    setActiveTab('chat');
  };

  if (!hasApiKey) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4 font-sans">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center border border-red-100">
          <div className="w-16 h-16 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Configuration Missing</h2>
          <p className="text-slate-600 mb-6">
            The API Key was not found in the environment variables. 
          </p>
        </div>
      </div>
    );
  }

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab}
      ticketCount={tickets.length}
    >
      {activeTab === 'chat' && (
        <ChatInterface 
          messages={messages}
          isLoading={isLoading}
          input={input}
          setInput={setInput}
          onSend={handleSendMessage}
        />
      )}
      
      {activeTab === 'knowledge' && (
        <KnowledgeBase items={knowledgeBase} />
      )}

      {activeTab === 'tickets' && (
        <TicketPanel tickets={tickets} onTicketUpdate={refreshTickets} />
      )}

      {activeTab === 'analytics' && (
        <AnalyticsDashboard tickets={tickets} />
      )}

      {activeTab === 'settings' && (
        <SettingsPanel 
          onClearHistory={handleClearHistory}
          onResetSystem={handleResetSystem}
        />
      )}
    </Layout>
  );
};

export default App;