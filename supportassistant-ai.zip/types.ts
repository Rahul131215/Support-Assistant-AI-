export interface Message {
  id: string;
  role: 'user' | 'model' | 'system';
  content: string;
  timestamp: string; // Changed to string for serialization stability
  isToolUse?: boolean;
}

export interface Ticket {
  id: string;
  title: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'In Progress' | 'Resolved';
  source: 'Chat Escalation' | 'Email' | 'Phone';
  description: string;
  created_at: string; // ISO string
  updated_at: string; // ISO string
}

export interface KnowledgeBaseItem {
  id: string;
  category: string;
  question: string;
  answer: string;
  tags?: string[];
}

export type EscalationParams = {
  summary: string;
  priority: string;
  reason: string;
};

export type ActiveTab = 'chat' | 'tickets' | 'analytics' | 'knowledge' | 'settings';

// Simulated Database State
export interface AppState {
  tickets: Ticket[];
  messages: Message[];
  knowledgeBase: KnowledgeBaseItem[];
}

export interface AnalyticsStats {
  totalTickets: number;
  openTickets: number;
  resolvedTickets: number;
  resolutionRate: number;
  avgResponseTime: string;
}