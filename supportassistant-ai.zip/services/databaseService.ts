import { Message, Ticket, KnowledgeBaseItem } from '../types';
import { INITIAL_KNOWLEDGE_BASE } from '../constants';

// Keys for LocalStorage
const STORAGE_KEYS = {
  MESSAGES: 'saas_ai_messages',
  TICKETS: 'saas_ai_tickets',
  KB: 'saas_ai_kb'
};

// Helper to simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

class DatabaseService {
  
  // --- Initialization ---
  constructor() {
    this.init();
  }

  private init() {
    const storage = this._getStorage();
    if (!storage) return;

    try {
        if (!storage.getItem(STORAGE_KEYS.KB)) {
            storage.setItem(STORAGE_KEYS.KB, JSON.stringify(INITIAL_KNOWLEDGE_BASE));
        }
        if (!storage.getItem(STORAGE_KEYS.TICKETS)) {
            storage.setItem(STORAGE_KEYS.TICKETS, JSON.stringify([]));
        }
    } catch (e) {
        console.warn("Storage initialization failed. App will use in-memory mode.", e);
    }
  }

  // Safe storage accessor
  private _getStorage(): Storage | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage;
      }
    } catch (e) {
      console.warn("LocalStorage access denied", e);
    }
    return null;
  }

  // --- Tickets CRUD ---
  async getTickets(): Promise<Ticket[]> {
    await delay(300); // Simulate network
    const storage = this._getStorage();
    if (!storage) return [];

    try {
        const data = storage.getItem(STORAGE_KEYS.TICKETS);
        if (!data) return [];
        
        const parsed = JSON.parse(data);
        // Critical safety check: Ensure it is actually an array
        return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
        console.error("Failed to fetch tickets", e);
        return [];
    }
  }

  async createTicket(ticket: Ticket): Promise<Ticket> {
    await delay(500);
    const tickets = await this.getTickets();
    const storage = this._getStorage();
    
    const newTicket = { ...ticket, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
    const updatedTickets = [newTicket, ...tickets];
    
    if (storage) {
        try {
            storage.setItem(STORAGE_KEYS.TICKETS, JSON.stringify(updatedTickets));
        } catch (e) {
            console.error("Failed to persist ticket", e);
        }
    }
    return newTicket;
  }

  async updateTicketStatus(id: string, status: Ticket['status']): Promise<void> {
    await delay(300);
    const tickets = await this.getTickets();
    const storage = this._getStorage();

    const index = tickets.findIndex(t => t.id === id);
    if (index !== -1 && storage) {
      tickets[index].status = status;
      tickets[index].updated_at = new Date().toISOString();
      try {
        storage.setItem(STORAGE_KEYS.TICKETS, JSON.stringify(tickets));
      } catch (e) {
        console.error("Failed to update ticket", e);
      }
    }
  }

  // --- Messages CRUD ---
  async getMessages(): Promise<Message[]> {
    const storage = this._getStorage();
    if (!storage) return [];

    try {
        const data = storage.getItem(STORAGE_KEYS.MESSAGES);
        if (!data) return [];

        const parsed = JSON.parse(data);
        // Critical safety check
        return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
        return [];
    }
  }

  async saveMessage(message: Message): Promise<void> {
    const messages = await this.getMessages();
    const storage = this._getStorage();
    
    messages.push(message);
    
    if (storage) {
        try {
            storage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
        } catch (e) {
            console.error("Failed to save message", e);
        }
    }
  }

  async clearMessages(): Promise<void> {
    const storage = this._getStorage();
    if (!storage) return;

    try {
        storage.removeItem(STORAGE_KEYS.MESSAGES);
    } catch (e) {
        console.error("Failed to clear messages", e);
    }
  }

  // --- Knowledge Base ---
  async getKnowledgeBase(): Promise<KnowledgeBaseItem[]> {
    const storage = this._getStorage();
    // Return default if no storage
    if (!storage) return INITIAL_KNOWLEDGE_BASE;

    try {
        const data = storage.getItem(STORAGE_KEYS.KB);
        if (!data) return INITIAL_KNOWLEDGE_BASE;
        
        const parsed = JSON.parse(data);
        // Robust check: Ensure array and not empty
        if (Array.isArray(parsed) && parsed.length > 0) {
             return parsed;
        }
        return INITIAL_KNOWLEDGE_BASE;
    } catch (e) {
      console.error("Failed to parse KB", e);
      return INITIAL_KNOWLEDGE_BASE;
    }
  }

  // --- System ---
  async resetSystem(): Promise<void> {
    const storage = this._getStorage();
    if (!storage) return;

    try {
        storage.clear();
        this.init();
    } catch (e) {
        console.error("Failed to reset system", e);
    }
  }
}

export const db = new DatabaseService();