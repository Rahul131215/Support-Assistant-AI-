import { GoogleGenAI as GenAIClient, FunctionDeclaration, Type, Tool } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";
import { retrieveContext } from "./ragService";

// 1. Define Tools
const escalateTicketTool: FunctionDeclaration = {
  name: 'escalate_ticket',
  description: 'Escalate a conversation to a human support agent or create a ticket. Use this for bugs, angry users, or complex questions.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      summary: {
        type: Type.STRING,
        description: 'A brief summary of the user issue.',
      },
      priority: {
        type: Type.STRING,
        description: 'The priority level: Low, Medium, High, or Critical.',
        enum: ['Low', 'Medium', 'High', 'Critical']
      },
      reason: {
        type: Type.STRING,
        description: 'Why this is being escalated.',
      },
    },
    required: ['summary', 'priority', 'reason'],
  },
};

const checkOrderStatusTool: FunctionDeclaration = {
  name: 'check_order_status',
  description: 'Check the status of a customer order.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      orderId: {
        type: Type.STRING,
        description: 'The order ID provided by the user (e.g., ORD-123).',
      },
    },
    required: ['orderId'],
  },
};

const tools: Tool[] = [
  {
    functionDeclarations: [escalateTicketTool, checkOrderStatusTool],
  },
];

let chatSession: any = null;

export const initializeChat = (apiKey: string, history: any[] = []) => {
  const client = new GenAIClient({ apiKey });
  
  chatSession = client.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      tools: tools,
      temperature: 0.7,
    },
    history: history,
  });
  
  return chatSession;
};

export const sendMessageToGemini = async (
  message: string, 
  onToolCall: (toolName: string, args: any) => Promise<any>
) => {
  if (!chatSession) throw new Error("Chat session not initialized");

  try {
    // RAG STEP: Retrieve relevant context
    const context = await retrieveContext(message);
    const augmentedMessage = context ? `${context}\n\nUser Query: ${message}` : message;

    if (context) {
        console.log("Context Injected:", context);
    }

    const result = await chatSession.sendMessage({ message: augmentedMessage });
    const response = result.candidates[0].content;
    
    // Check for function calls
    const functionCalls = response.parts?.filter((part: any) => part.functionCall);

    if (functionCalls && functionCalls.length > 0) {
      // Execute simulated tools on the client side
      const toolResponses = [];
      
      for (const call of functionCalls) {
        const fc = call.functionCall;
        console.log("AI requested tool execution:", fc.name, fc.args);
        
        // Execute the client-side logic for the tool
        const toolResult = await onToolCall(fc.name, fc.args);
        
        toolResponses.push({
          functionResponse: {
            name: fc.name,
            id: fc.id, // Important for tracking which call this response is for
            response: { result: toolResult },
          }
        });
      }

      // Send the tool results back to AI so it can generate a final text response
      const finalResult = await chatSession.sendMessage(toolResponses);
      return finalResult.candidates[0].content.parts.map((p: any) => p.text).join('');
    }

    // Return normal text
    return response.parts.map((p: any) => p.text).join('');

  } catch (error) {
    console.error("AI Service Error:", error);
    throw error;
  }
};