import { KnowledgeBaseItem } from "../types";
import { db } from "./databaseService";

// A lightweight RAG implementation
// In a real app, this would use vector embeddings (ChromaDB/Pinecone).
// Here, we use keyword matching + scoring to simulate retrieval.

export const retrieveContext = async (query: string): Promise<string> => {
  const kb = await db.getKnowledgeBase();
  
  if (!Array.isArray(kb)) return ""; // Safety check

  const lowerQuery = query.toLowerCase();
  
  // Score each KB item based on relevance
  const scoredItems = kb.map(item => {
    let score = 0;
    // Combine all fields and handle nulls safely
    const content = ((item.question || "") + " " + (item.answer || "") + " " + (item.category || "")).toLowerCase();
    
    // Simple keyword matching
    const terms = lowerQuery.split(" ");
    terms.forEach(term => {
      if (term.length > 3 && content.includes(term)) {
        score += 1;
      }
    });

    // Boost if category is mentioned
    if (item.category && lowerQuery.includes(item.category.toLowerCase())) {
      score += 2;
    }

    return { item, score };
  });

  // Filter and Sort
  const relevantItems = scoredItems
    .filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3) // Top 3 results
    .map(x => x.item);

  if (relevantItems.length === 0) return "";

  // Format context for the LLM
  const contextString = relevantItems.map(item => 
    `Q: ${item.question}\nA: ${item.answer}`
  ).join("\n---\n");

  return `\nRELEVANT KNOWLEDGE BASE ENTRIES:\n${contextString}\n\nUse the above information to answer the user's question if applicable.\n`;
};