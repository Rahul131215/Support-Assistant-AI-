import { KnowledgeBaseItem } from "./types";

export const INITIAL_KNOWLEDGE_BASE: KnowledgeBaseItem[] = [
  {
    id: 'kb-1',
    category: 'Billing',
    question: 'How do I request a refund?',
    answer: 'Refunds can be requested within 30 days of purchase via the settings dashboard. Process takes 3-5 business days.'
  },
  {
    id: 'kb-2',
    category: 'Account',
    question: 'How do I reset my password?',
    answer: 'Click "Forgot Password" on the login screen. You will receive an email reset link.'
  },
  {
    id: 'kb-3',
    category: 'Technical',
    question: 'Where can I find the API keys?',
    answer: 'API keys are located in Developer Settings > Access Tokens. Never share these publicly.'
  }
];

export const SYSTEM_INSTRUCTION = `
You are SupportAssistant, a Tier 1 AI Customer Support Agent for a SaaS platform.
Your goal is to answer user questions based on your internal knowledge.

RULES:
1. Always be polite, professional, and concise.
2. If the user asks a question found in your context, answer it directly.
3. If the user reports a bug, is angry, or has a complex request you cannot solve, you MUST use the 'escalate_ticket' tool.
4. If the user asks about order status, use the 'check_order_status' tool.
5. Do not make up facts. If you don't know, suggest escalating the ticket.

When you use a tool, inform the user you are doing so (e.g., "I'm escalating this to a human agent now...").
`;