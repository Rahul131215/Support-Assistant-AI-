import React, { useMemo } from 'react';
import { Ticket } from '../types';
import { BarChart3, TrendingUp, Users, CheckCircle, Clock } from 'lucide-react';

interface AnalyticsDashboardProps {
  tickets: Ticket[];
}

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ tickets = [] }) => {
  const stats = useMemo(() => {
    // Safety check in case tickets is null/undefined
    if (!Array.isArray(tickets)) return { total: 0, resolved: 0, open: 0, inProgress: 0, rate: 0 };

    const total = tickets.length;
    const resolved = tickets.filter(t => t.status === 'Resolved').length;
    const open = tickets.filter(t => t.status === 'Open').length;
    const inProgress = tickets.filter(t => t.status === 'In Progress').length;
    const rate = total > 0 ? Math.round((resolved / total) * 100) : 0;

    return { total, resolved, open, inProgress, rate };
  }, [tickets]);

  return (
    <div className="h-full p-8 bg-slate-50 overflow-y-auto animate-slide-up">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Analytics Overview</h2>
            <p className="text-slate-500 mt-1">Real-time performance metrics for the support system.</p>
          </div>
          <div className="bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm text-sm text-slate-600">
            Last updated: <span className="font-semibold">Just now</span>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard 
                label="Total Tickets" 
                value={stats.total} 
                icon={<BarChart3 className="text-blue-600" size={24} />} 
                trend="+12% from last week"
                variant="blue"
            />
            <StatCard 
                label="Resolution Rate" 
                value={`${stats.rate}%`} 
                icon={<CheckCircle className="text-emerald-600" size={24} />} 
                trend="Top 10% in industry"
                variant="emerald"
            />
            <StatCard 
                label="Active Issues" 
                value={stats.open + stats.inProgress} 
                icon={<TrendingUp className="text-amber-600" size={24} />} 
                trend="Requires attention"
                variant="amber"
            />
            <StatCard 
                label="Avg Response" 
                value="1m 42s" 
                icon={<Clock className="text-indigo-600" size={24} />} 
                trend="AI Assisted"
                variant="indigo"
            />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Ticket Status Distribution */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2">
                <h3 className="font-bold text-slate-800 mb-6">Ticket Status Distribution</h3>
                <div className="space-y-6">
                    <ProgressBar label="Resolved" count={stats.resolved} total={stats.total} colorClass="bg-emerald-500" />
                    <ProgressBar label="In Progress" count={stats.inProgress} total={stats.total} colorClass="bg-blue-500" />
                    <ProgressBar label="Open" count={stats.open} total={stats.total} colorClass="bg-amber-500" />
                </div>
            </div>

            {/* AI Usage */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col items-center justify-center text-center">
                <div className="relative w-40 h-40 mb-4">
                    <svg className="w-full h-full transform -rotate-90">
                        <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="15" fill="transparent" className="text-slate-100" />
                        <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="15" fill="transparent" strokeDasharray={440} strokeDashoffset={440 - (440 * 0.85)} className="text-indigo-600 transition-all duration-1000 ease-out" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <span className="text-3xl font-bold text-indigo-700">85%</span>
                        <span className="text-xs text-slate-500 font-medium uppercase">Automated</span>
                    </div>
                </div>
                <h3 className="font-bold text-slate-800">AI Deflection Rate</h3>
                <p className="text-sm text-slate-500 mt-2 px-4">
                    Percentage of queries resolved by AI without human escalation.
                </p>
            </div>
        </div>

      </div>
    </div>
  );
};

const STAT_STYLES = {
    blue: { border: 'border-l-blue-500', bg: 'bg-blue-50' },
    emerald: { border: 'border-l-emerald-500', bg: 'bg-emerald-50' },
    amber: { border: 'border-l-amber-500', bg: 'bg-amber-50' },
    indigo: { border: 'border-l-indigo-500', bg: 'bg-indigo-50' },
};

const StatCard = ({ label, value, icon, trend, variant }: { label: string, value: string | number, icon: React.ReactNode, trend: string, variant: 'blue' | 'emerald' | 'amber' | 'indigo' }) => {
    
    const activeStyle = STAT_STYLES[variant] || STAT_STYLES.blue;

    return (
        <div className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow border-l-4 ${activeStyle.border}`}>
            <div className="flex justify-between items-start mb-4">
                <div>
                    <p className="text-slate-500 text-sm font-medium">{label}</p>
                    <h3 className="text-3xl font-bold text-slate-800 mt-1">{value}</h3>
                </div>
                <div className={`p-3 rounded-xl ${activeStyle.bg}`}>
                    {icon}
                </div>
            </div>
            <div className="text-xs font-medium text-slate-400 flex items-center gap-1">
                {trend}
            </div>
        </div>
    );
};

const ProgressBar = ({ label, count, total, colorClass }: { label: string, count: number, total: number, colorClass: string }) => {
    const percentage = total > 0 ? (count / total) * 100 : 0;
    return (
        <div>
            <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-slate-700">{label}</span>
                <span className="text-sm font-medium text-slate-500">{count} ({Math.round(percentage)}%)</span>
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div 
                    className={`h-full rounded-full transition-all duration-1000 ${colorClass}`} 
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>
        </div>
    );
};

export default AnalyticsDashboard;