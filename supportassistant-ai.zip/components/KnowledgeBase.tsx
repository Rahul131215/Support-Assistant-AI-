import React, { useState, useMemo } from 'react';
import { KnowledgeBaseItem } from '../types';
import { BookOpen, Search, X } from 'lucide-react';

interface KnowledgeBaseProps {
  items: KnowledgeBaseItem[];
}

const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ items }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = useMemo(() => {
    if (!searchQuery.trim()) return items;
    const lowerQuery = searchQuery.toLowerCase();
    
    return items.filter(item => {
      // Safe guard against missing fields to prevent crashes
      const q = item.question?.toLowerCase() || '';
      const a = item.answer?.toLowerCase() || '';
      const c = item.category?.toLowerCase() || '';
      
      return q.includes(lowerQuery) || a.includes(lowerQuery) || c.includes(lowerQuery);
    });
  }, [items, searchQuery]);

  return (
    <div className="h-full p-8 bg-slate-50 overflow-y-auto animate-slide-up">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white shadow-md mb-4 text-indigo-600 border border-slate-100 transform -rotate-3">
             <BookOpen size={32} />
          </div>
          <h2 className="text-3xl font-bold text-slate-800 mb-3">Knowledge Base</h2>
          <p className="text-slate-500 max-w-lg mx-auto">
            This data is injected into the AI's context window (RAG), allowing it to answer specific business questions accurately.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3 relative">
                <Search className="text-slate-400" size={20} />
                <input 
                    type="text" 
                    placeholder="Search knowledge articles..." 
                    className="bg-transparent border-none outline-none text-sm w-full text-slate-600 placeholder:text-slate-400"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-4 p-1 hover:bg-slate-200 rounded-full text-slate-400 transition-colors"
                  >
                    <X size={16} />
                  </button>
                )}
            </div>
            <div className="divide-y divide-slate-100">
            {filteredItems.length === 0 ? (
                <div className="p-12 text-center text-slate-400 flex flex-col items-center">
                    <Search size={32} className="mb-2 opacity-50" />
                    <p>No articles found matching "{searchQuery}"</p>
                    {items.length === 0 && (
                      <p className="text-xs mt-2 text-slate-300">Database is empty.</p>
                    )}
                </div>
            ) : (
                filteredItems.map((item, idx) => (
                    <div 
                        key={item.id} 
                        className="p-6 hover:bg-slate-50/80 transition-colors group cursor-default animate-fade-in"
                        style={{ animationDelay: `${idx * 0.05}s` }}
                    >
                    <div className="flex items-center gap-3 mb-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-indigo-50 text-indigo-600 border border-indigo-100">
                            {item.category}
                        </span>
                        <h3 className="text-base font-semibold text-slate-800 group-hover:text-indigo-700 transition-colors">{item.question}</h3>
                    </div>
                    <p className="text-slate-600 text-sm leading-relaxed pl-1 border-l-2 border-indigo-200 ml-1">
                        {item.answer}
                    </p>
                    </div>
                ))
            )}
            </div>
            <div className="p-4 bg-slate-50 text-center border-t border-slate-100 flex items-center justify-center gap-2">
                <p className="text-xs text-slate-400 italic">
                    Simulating vector retrieval from simulated database
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBase;