import React from 'react';
import { Settings, MessageSquare, Database, Bell, Zap, BarChart3 } from 'lucide-react';
import { ActiveTab } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  ticketCount: number;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, ticketCount }) => {
  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-20 lg:w-72 bg-slate-900 text-white flex flex-col items-center lg:items-stretch py-6 transition-all duration-300 z-30 shadow-2xl shrink-0">
        <div className="px-4 mb-10 flex items-center justify-center lg:justify-start gap-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30 shrink-0">
            <Zap className="text-white fill-white" size={20} />
          </div>
          <div className="hidden lg:block overflow-hidden">
             <h1 className="font-bold text-xl tracking-tight leading-none">SupportAI</h1>
             <span className="text-xs text-slate-400 font-medium">Enterprise Agent</span>
          </div>
        </div>

        <nav className="flex-1 w-full px-3 space-y-2">
          <NavButton 
            active={activeTab === 'chat'} 
            onClick={() => setActiveTab('chat')} 
            icon={<MessageSquare size={20} />} 
            label="Live Chat" 
            description="Interact with the Agent"
          />
          <NavButton 
            active={activeTab === 'tickets'} 
            onClick={() => setActiveTab('tickets')} 
            icon={<Bell size={20} />} 
            label="Escalations" 
            badge={ticketCount}
            description="Active support tickets"
          />
           <NavButton 
            active={activeTab === 'analytics'} 
            onClick={() => setActiveTab('analytics')} 
            icon={<BarChart3 size={20} />} 
            label="Analytics" 
            description="System performance"
          />
          <NavButton 
            active={activeTab === 'knowledge'} 
            onClick={() => setActiveTab('knowledge')} 
            icon={<Database size={20} />} 
            label="Knowledge Base" 
            description="RAG Context Source"
          />
        </nav>

        <div className="px-3 mt-auto">
          <div className="w-full h-px bg-slate-800 mb-4 mx-auto w-[80%]"></div>
          <NavButton 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
            icon={<Settings size={20} />} 
            label="Settings" 
            description="Configure system"
          />
          
          <div className="mt-6 hidden lg:flex items-center gap-3 px-4 py-3 bg-slate-800/50 rounded-xl mx-2 border border-slate-700/50">
             <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-400 to-purple-400 flex items-center justify-center text-xs font-bold shadow-inner">
                RA
             </div>
             <div className="overflow-hidden">
                <p className="text-sm font-medium text-white truncate">Rahul</p>
                <p className="text-xs text-slate-400 truncate">Project Owner</p>
             </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative bg-slate-50">
        <header className="bg-white h-16 border-b border-slate-200 flex items-center justify-between px-8 shadow-sm z-20 shrink-0">
          <div className="flex items-center gap-2">
             <h1 className="text-xl font-semibold text-slate-800 capitalize tracking-tight">
               {activeTab === 'chat' && 'Support Console'}
               {activeTab === 'tickets' && 'Escalation Dashboard'}
               {activeTab === 'analytics' && 'Performance Analytics'}
               {activeTab === 'knowledge' && 'Knowledge Base Index'}
               {activeTab === 'settings' && 'System Configuration'}
             </h1>
          </div>
          <div className="flex items-center gap-6">
             <div className="flex flex-col items-end">
               <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Status</span>
               <div className="flex items-center gap-1.5">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-sm font-medium text-slate-700">System Online</span>
               </div>
             </div>
          </div>
        </header>
        
        {/* Content Area */}
        <div className="flex-1 overflow-hidden relative">
          {children}
        </div>
      </main>
    </div>
  );
};

const NavButton = ({ active, onClick, icon, label, badge, description }: any) => (
  <button
    onClick={onClick}
    className={`w-full p-3 rounded-xl flex items-center justify-center lg:justify-start gap-3 transition-all duration-200 group relative
      ${active 
        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 translate-x-1' 
        : 'text-slate-400 hover:bg-slate-800 hover:text-white hover:translate-x-1'}
    `}
  >
    <div className={`${active ? 'text-white' : 'text-slate-400 group-hover:text-white'}`}>
      {icon}
    </div>
    <div className="hidden lg:block text-left">
        <span className={`block font-medium text-sm ${active ? 'text-white' : 'text-slate-300 group-hover:text-white'}`}>{label}</span>
    </div>
    
    {badge > 0 && (
      <span className="absolute top-2 right-2 lg:top-auto lg:right-3 lg:static ml-auto bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">
        {badge}
      </span>
    )}
  </button>
);

export default Layout;