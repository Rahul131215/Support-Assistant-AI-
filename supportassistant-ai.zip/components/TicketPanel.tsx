import React from 'react';
import { Ticket } from '../types';
import { AlertCircle, CheckCircle2, Clock, Ticket as TicketIcon, MoreHorizontal } from 'lucide-react';
import { db } from '../services/databaseService';

interface TicketPanelProps {
  tickets: Ticket[];
  onTicketUpdate: () => void; // Callback to refresh data
}

const TicketPanel: React.FC<TicketPanelProps> = ({ tickets, onTicketUpdate }) => {
  const getPriorityColor = (p: string) => {
    switch (p) {
      case 'Critical': return 'bg-red-50 text-red-700 border-red-200 ring-red-100';
      case 'High': return 'bg-orange-50 text-orange-700 border-orange-200 ring-orange-100';
      case 'Medium': return 'bg-yellow-50 text-yellow-700 border-yellow-200 ring-yellow-100';
      default: return 'bg-blue-50 text-blue-700 border-blue-200 ring-blue-100';
    }
  };

  const handleStatusChange = async (id: string, newStatus: Ticket['status']) => {
      await db.updateTicketStatus(id, newStatus);
      onTicketUpdate();
  };

  return (
    <div className="h-full p-8 bg-slate-50 overflow-y-auto animate-slide-up">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex justify-between items-end">
            <div>
                <h2 className="text-2xl font-bold text-slate-800">Support Tickets</h2>
                <p className="text-slate-500 mt-1">Real-time persistent database of customer issues</p>
            </div>
            <div className="text-sm font-semibold text-indigo-700 bg-indigo-50 px-4 py-1.5 rounded-full border border-indigo-200 shadow-sm">
                Total Escalations: {tickets.length}
            </div>
        </div>

        {tickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 bg-white rounded-2xl border border-dashed border-slate-300 text-center animate-fade-in">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                <TicketIcon size={32} className="text-slate-300" />
            </div>
            <h3 className="text-lg font-semibold text-slate-700">No active tickets</h3>
            <p className="text-slate-400 max-w-sm mt-1">
              Tickets will appear here when the AI determines a user needs human assistance.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {tickets.map((ticket, idx) => (
              <div 
                key={ticket.id} 
                className={`bg-white p-5 rounded-2xl border shadow-sm hover:shadow-md transition-all animate-slide-up group flex flex-col
                  ${ticket.status === 'Resolved' ? 'border-emerald-100 bg-emerald-50/10 opacity-75' : 'border-slate-200'}
                `}
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <div className="flex justify-between items-start mb-4">
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-md border ring-4 ring-opacity-50 ${getPriorityColor(ticket.priority)}`}>
                    {ticket.priority}
                  </span>
                  <div className="flex items-center gap-2">
                     <span className={`w-2 h-2 rounded-full ${ticket.status === 'Open' ? 'bg-amber-500' : ticket.status === 'In Progress' ? 'bg-blue-500' : 'bg-emerald-500'}`}></span>
                     <span className="text-xs text-slate-500 font-medium">{ticket.status}</span>
                  </div>
                </div>
                
                <h3 className="font-semibold text-slate-800 mb-2 truncate pr-2 group-hover:text-indigo-600 transition-colors">{ticket.title}</h3>
                <p className="text-sm text-slate-500 mb-5 line-clamp-3 leading-relaxed flex-1">
                  {ticket.description}
                </p>

                <div className="pt-4 border-t border-slate-100 flex justify-between items-center mt-auto">
                  <span className="text-xs font-mono text-slate-400 bg-slate-50 px-2 py-1 rounded border border-slate-100">{ticket.id}</span>
                  
                  <div className="flex gap-2">
                    {ticket.status !== 'Resolved' && (
                        <button 
                            onClick={() => handleStatusChange(ticket.id, 'Resolved')}
                            className="text-xs font-medium bg-emerald-50 text-emerald-600 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition-colors"
                        >
                            Mark Resolved
                        </button>
                    )}
                     {ticket.status === 'Resolved' && (
                        <button 
                            onClick={() => handleStatusChange(ticket.id, 'Open')}
                            className="text-xs font-medium bg-slate-50 text-slate-500 hover:bg-slate-100 px-3 py-1.5 rounded-lg transition-colors"
                        >
                            Reopen
                        </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TicketPanel;