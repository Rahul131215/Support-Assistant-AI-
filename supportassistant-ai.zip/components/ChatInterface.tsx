import React, { useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Sparkles, ArrowRight } from 'lucide-react';
import { Message } from '../types';

interface ChatInterfaceProps {
  messages: Message[];
  isLoading: boolean;
  input: string;
  setInput: (val: string) => void;
  onSend: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isLoading, input, setInput, onSend }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  const handleQuickAction = (text: string) => {
      setInput(text);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 relative animate-fade-in">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scrollbar-hide">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-slate-400 animate-slide-up">
            <div className="w-20 h-20 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center mb-6">
                <Bot size={40} className="text-indigo-500" />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">How can I help you today?</h2>
            <p className="text-slate-500 max-w-md text-center mb-8">
              I'm connected to your knowledge base and ticket system. Ask me about orders, policies, or technical issues.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-lg">
                <QuickActionCard onClick={() => handleQuickAction("How do I request a refund?")} text="How do I request a refund?" />
                <QuickActionCard onClick={() => handleQuickAction("Check status for order ORD-123")} text="Check status for order ORD-123" />
                <QuickActionCard onClick={() => handleQuickAction("The system is down, I need help!")} text="Report a critical system bug" />
                <QuickActionCard onClick={() => handleQuickAction("Reset my password")} text="Reset my password" />
            </div>
          </div>
        )}
        
        {messages.map((msg, idx) => (
          <div
            key={msg.id}
            className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}
            style={{ animationDelay: `${idx * 0.05}s` }}
          >
            <div className={`flex max-w-[90%] md:max-w-[75%] gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              
              {/* Avatar */}
              <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-1 shadow-sm
                ${msg.role === 'user' 
                    ? 'bg-gradient-to-br from-indigo-500 to-indigo-600 text-white' 
                    : 'bg-white border border-slate-200 text-emerald-600'}
              `}>
                {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
              </div>

              {/* Bubble */}
              <div className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                  <div className={`p-4 rounded-2xl shadow-sm text-sm leading-relaxed whitespace-pre-wrap relative group
                    ${msg.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-sm' 
                      : 'bg-white text-slate-700 border border-slate-200 rounded-tl-sm'
                    }
                  `}>
                    {msg.content}
                  </div>
                  <span className="text-[10px] text-slate-300 mt-1 px-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </span>
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex w-full justify-start animate-fade-in">
            <div className="flex gap-3">
              <div className="w-9 h-9 rounded-full bg-white border border-slate-200 text-emerald-600 flex items-center justify-center flex-shrink-0 mt-1">
                <Bot size={18} />
              </div>
              <div className="bg-white border border-slate-200 px-5 py-4 rounded-2xl rounded-tl-sm shadow-sm flex items-center gap-3">
                 <div className="flex space-x-1.5">
                    <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-150"></div>
                    <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-300"></div>
                 </div>
                 <span className="text-slate-400 text-xs font-medium uppercase tracking-wider">Reasoning</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} className="h-4" />
      </div>

      {/* Input Area */}
      <div className="p-4 md:p-6 bg-white/80 backdrop-blur-md border-t border-slate-200 z-20">
        <div className="max-w-4xl mx-auto relative flex items-center gap-3">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message here..."
            className="flex-1 bg-slate-100/50 border border-slate-200 text-slate-800 text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 block w-full p-4 pl-5 transition-all outline-none placeholder:text-slate-400 shadow-inner"
            disabled={isLoading}
          />
          <button
            onClick={onSend}
            disabled={!input.trim() || isLoading}
            className="p-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/40 active:scale-95 flex items-center justify-center w-14 h-14"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} className="ml-0.5" />}
          </button>
        </div>
        <div className="max-w-4xl mx-auto mt-2.5 text-center flex items-center justify-center gap-2">
            <Sparkles size={12} className="text-indigo-400" />
            <p className="text-[10px] text-slate-400 font-medium">Enterprise AI System • Made by Rahul</p>
        </div>
      </div>
    </div>
  );
};

const QuickActionCard = ({ text, onClick }: { text: string, onClick: () => void }) => (
    <button 
        onClick={onClick}
        className="text-left p-3 rounded-xl border border-slate-200 bg-white hover:border-indigo-300 hover:shadow-md hover:shadow-indigo-100 transition-all group flex items-center justify-between"
    >
        <span className="text-xs md:text-sm font-medium text-slate-600 group-hover:text-indigo-700">{text}</span>
        <ArrowRight size={14} className="text-slate-300 group-hover:text-indigo-500 opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
    </button>
);

export default ChatInterface;