import React from 'react';
import { Trash2, RefreshCw, Database, Server, Shield } from 'lucide-react';

interface SettingsPanelProps {
  onClearHistory: () => void;
  onResetSystem: () => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ onClearHistory, onResetSystem }) => {
  return (
    <div className="h-full p-8 bg-slate-50 overflow-y-auto animate-slide-up">
      <div className="max-w-3xl mx-auto space-y-8">
        
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-slate-800">System Settings</h2>
          <p className="text-slate-500 mt-1">Manage system configurations and data retention policies.</p>
        </div>

        {/* Data Management Section */}
        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
            <Database size={18} className="text-indigo-500" />
            <h3 className="font-semibold text-slate-800">Data Management</h3>
          </div>
          
          <div className="p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-slate-700">Clear Session Data</h4>
                <p className="text-sm text-slate-500">Removes all active messages from the current session context.</p>
              </div>
              <button 
                onClick={onClearHistory}
                className="px-4 py-2 bg-white border border-slate-300 text-slate-700 font-medium rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors flex items-center gap-2"
              >
                <Trash2 size={16} />
                Clear Chat
              </button>
            </div>

            <div className="w-full h-px bg-slate-100"></div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-slate-700">System Reset</h4>
                <p className="text-sm text-slate-500">Restores application state to factory defaults.</p>
              </div>
              <button 
                onClick={onResetSystem}
                className="px-4 py-2 bg-rose-50 border border-rose-200 text-rose-600 font-medium rounded-lg hover:bg-rose-100 transition-colors flex items-center gap-2"
              >
                <RefreshCw size={16} />
                Reset System
              </button>
            </div>
          </div>
        </section>

        {/* System Info Section */}
        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-slide-up delay-100">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
            <Server size={18} className="text-emerald-500" />
            <h3 className="font-semibold text-slate-800">System Environment</h3>
          </div>
          
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <InfoItem label="AI Engine" value="Enterprise LLM v2.5" />
            <InfoItem label="API Status" value="Connected" status="success" />
            <InfoItem label="Backend Status" value="Active (Node.js Service)" />
            <InfoItem label="Latency Optimization" value="Enabled (1500ms)" />
            <InfoItem label="Vector Database" value="Active (RAG/Embeddings)" />
            <InfoItem label="Environment" value="Production / Web" />
          </div>
        </section>

         {/* Security */}
         <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-slide-up delay-200">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
            <Shield size={18} className="text-blue-500" />
            <h3 className="font-semibold text-slate-800">Security & Compliance</h3>
          </div>
          <div className="p-6">
            <div className="flex items-start gap-4">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                    <Shield size={24} />
                </div>
                <div>
                    <h4 className="font-medium text-slate-800">Data Protection Policy</h4>
                    <p className="text-sm text-slate-500 mt-1">
                        All interactions are processed in a secure environment. Session data is persisted locally for performance and is not shared with third-party tracking systems.
                    </p>
                </div>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
};

const InfoItem = ({ label, value, status }: { label: string, value: string, status?: 'success' | 'error' }) => (
  <div>
    <h5 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">{label}</h5>
    <div className="flex items-center gap-2">
      {status === 'success' && <div className="w-2 h-2 rounded-full bg-emerald-500"></div>}
      <span className="text-slate-700 font-medium">{value}</span>
    </div>
  </div>
);

export default SettingsPanel;